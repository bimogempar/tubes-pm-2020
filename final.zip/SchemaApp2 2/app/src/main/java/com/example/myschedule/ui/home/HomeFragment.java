package com.example.myschedule.ui.home;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.example.myschedule.R;
import com.example.myschedule.addkelas;
import com.example.myschedule.profilDosenFragment;

import java.util.ArrayList;
import java.util.Arrays;

public class HomeFragment extends Fragment {

    ImageView add;
    ListView listView;
    TextView mapel, semester, dosen;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_home, container, false);
        listView = (ListView) v.findViewById(R.id.lvhome);
        mapel = (TextView) v.findViewById(R.id.mapel);
        semester = (TextView) v.findViewById(R.id.semester);
        dosen = (TextView) v.findViewById(R.id.namadosen);
        add = v.findViewById(R.id.add);
        final String[] dosen = getResources().getStringArray(R.array.Dosen);
        final profilDosenFragment pdf = new profilDosenFragment();

        setupListView();

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Bundle bundle = new Bundle();
                bundle.putString("namadosen", dosen[position]);
                pdf.setArguments(bundle);
                getFragmentManager().beginTransaction()
                        .setCustomAnimations(android.R.anim.slide_in_left, android.R.anim.slide_out_right)
                        .replace(R.id.nav_host_fragment, pdf).commit();
            }
        });

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentTransaction ts = getFragmentManager().beginTransaction();
                ts.setCustomAnimations(android.R.anim.slide_in_left, android.R.anim.slide_out_right);
                ts.replace(R.id.nav_host_fragment, new addkelas());
                ts.commit();
            }
        });

        return v;
    }

    public class SimpleAdapter extends BaseAdapter {

        public Context mContext;
        public LayoutInflater layoutInflater;
        public TextView title, semt, dosen;
        public String[] titleArray;
        public String[] semtArray;
        public String[] dosenArray;
        public ImageView imageView;
        public LinearLayout linearLayout;


        public SimpleAdapter(Context context, String[] title, String[] semt, String[] dosen) {
            mContext = context;
            titleArray = title;
            semtArray = semt;
            dosenArray = dosen;
            layoutInflater = LayoutInflater.from(context);

        }

        @Override
        public int getCount() {
            return titleArray.length;
        }

        @Override
        public Object getItem(int position) {
            return titleArray[position];
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            if (convertView == null) {
                convertView = layoutInflater.inflate(R.layout.item_class, null);
            }

            title = (TextView) convertView.findViewById(R.id.mapel);
            semt = (TextView) convertView.findViewById(R.id.semester);
            dosen = (TextView) convertView.findViewById(R.id.namadosen);
            imageView = (ImageView) convertView.findViewById(R.id.fotodosen);
            linearLayout = (LinearLayout) convertView.findViewById(R.id.kelas);

            title.setText(titleArray[position]);
            semt.setText(semtArray[position]);
            dosen.setText(dosenArray[position]);

            if (titleArray[position].equalsIgnoreCase("Pemrograman Mobile")) {
                imageView.setImageResource(R.drawable.logo2);
                linearLayout.setBackgroundResource(R.drawable.kelasbg);
            } else if (titleArray[position].equalsIgnoreCase("Pemrograman Web")) {
                imageView.setImageResource(R.drawable.logo2);
                linearLayout.setBackgroundResource(R.drawable.kelasbgmerah);
            } else if (titleArray[position].equalsIgnoreCase("Basis Data")) {
                imageView.setImageResource(R.drawable.logo2);
                linearLayout.setBackgroundResource(R.drawable.kelasbgungu);
            } else if (titleArray[position].equalsIgnoreCase("Sistem Operasi")) {
                imageView.setImageResource(R.drawable.logo2);
                linearLayout.setBackgroundResource(R.drawable.kelasbgorange);
            }
            return convertView;
        }
    }

    public void setupListView() {
        String[] title = getResources().getStringArray(R.array.Mapel);
        String[] semt = getResources().getStringArray(R.array.Semt);
        String[] dosen1 = getResources().getStringArray(R.array.Dosen);

        SimpleAdapter simpleAdapter = new SimpleAdapter(getContext(), title, semt, dosen1);
        listView.setAdapter(simpleAdapter);

    }
}
