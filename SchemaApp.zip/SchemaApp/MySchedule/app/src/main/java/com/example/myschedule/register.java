package com.example.myschedule;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
public class register extends AppCompatActivity {

    TextView masuk;
    Button daftar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        masuk = findViewById(R.id.inimasuk);

        masuk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent callMain = new Intent(register.this,MainActivity.class);
                startActivity(callMain);
            }
        });

        daftar = findViewById(R.id.button);

        daftar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent callMain2 = new Intent(register.this,MainActivity.class);
                startActivity(callMain2);
            }
        });
    }
    }